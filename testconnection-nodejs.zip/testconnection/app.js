
const mysql = require('mysql');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 8088;
app.use(bodyParser.json());

var mysqlconnection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'testconnectiondb',
    multiplestatement: true
});

mysqlconnection.connect((err) => {
    if(!err) {
        console.log("DB Connection succeded.");
    }
    else {
        console.log("DB Connection Failed \n Error:" + JSON.stringify(err, undefined, 2));
    }
});

app.post('/saveData', (req, res) => {
    var sb = JSON.parse(JSON.stringify(req.body));
    //Insert data to database
    mysqlconnection.query("INSERT INTO tblperson (full_name, status) VALUES (?, ?);", [ sb.full_name, sb.status ], (err, rows, fields)=> {
        if(!err) {
            res.json({
                status: "ok",
                msg: "Successfully Signed Up."
			});
        }
        else {
            console.log(err);
        }
    })
})

app.get('/getAllPerson', (req, res) => {
    mysqlconnection.query("SELECT * From tblperson", (err, rows, fields)=> {
        if(!err) {
            console.log(rows);
            res.json({
                status: "ok",
                data: rows
			})
        }
        else {
            console.log(err);
        }
    })
})

app.listen(port)
console.log("API server started on port: " + port)