package com.example.testconnection;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;

public class APIHandler {
    private static final String TAG = "API Request";

    public static void postRequest(JSONObject json, String url, Context context) {
        final Context myContext = context;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, json,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, "onResponse: POST " + response.toString());
                        try{
                            String msg = response.getString("msg");
                            AppURLConfig.toastMessage(myContext, msg);
                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG, "onErrorResponse: POST " + error);
            }
        });
        RequestQueue MyRequestQueue = Volley.newRequestQueue(myContext);
        MyRequestQueue.add(jsonObjectRequest);
    }

    public static void getAllPerson(String url, Context context, ListView lv, AppCompatActivity ac, ArrayList<HashMap<String, String>> dt) {
        // Initialize a new RequestQueue instance
        final ListView list_view = lv;
        final AppCompatActivity app_comp = ac;
        final ArrayList<HashMap<String, String>> data_list = dt;
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        // Initialize a new JsonObjectRequest instance
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, "GET " + response.toString());
                        // Process the JSON response
                        try{
                            String resp_status = response.getString("status");
                            Log.d(TAG, "STATUS " + resp_status);
                            // Get the JSON array
                            JSONArray array = response.getJSONArray("data");
                            // Loop through the array elements
                            for(int i=0;i<array.length();i++){
                                // Get current json object
                                JSONObject student = array.getJSONObject(i);
                                // Get the current student (json object) data
                                String full_name = student.getString("full_name");
                                String status = student.getString("status");

                                HashMap<String, String> data = new HashMap<>();
                                // adding to HashMap key => value
                                data.put("full_name", full_name);
                                data.put("status", status);

                                // adding contact to data list
                                data_list.add(data);
                            }
                            // Adding the information to list adapter then set to list view
                            ListAdapter adapter = new SimpleAdapter(app_comp, data_list, R.layout.list_item, new String[]{"full_name", "status"}, new int[]{R.id.name, R.id.status});
                            list_view.setAdapter(adapter);

                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        // Do something when error occurred
                        Log.d(TAG, "onErrorResponse: GET" + error);
                    }
                }

        );
        // Add JsonObjectRequest to the RequestQueue
        requestQueue.add(jsonObjectRequest);
    }
}
