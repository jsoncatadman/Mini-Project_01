package com.example.testconnection;

import android.widget.Toast;
import android.content.Context;

public class AppURLConfig {
    public static String SAVEDATA_URL = "http://192.168.1.6:8088/saveData";
    public static String GETDATA_URL = "http://192.168.1.6:8088/getAllPerson";

    public static void toastMessage(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
