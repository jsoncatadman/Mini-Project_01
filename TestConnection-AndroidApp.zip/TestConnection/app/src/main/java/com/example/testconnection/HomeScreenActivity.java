package com.example.testconnection;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.content.Context;
import org.json.JSONException;
import org.json.JSONObject;


public class HomeScreenActivity  extends AppCompatActivity {
    private Button btn_save, btn_show;
    private EditText name_txt, status_txt;
    private Context myContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_home_screen);
        myContext = getApplicationContext();
        name_txt = findViewById(R.id.name_txt);
        status_txt = findViewById(R.id.status_txt);
        btn_show = findViewById(R.id.btn_show);
        // POST Request: Sending Data
        btn_save = findViewById(R.id.btn_save);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = name_txt.getText().toString();
                String status = status_txt.getText().toString();

                if(!name.equals("") && !status.equals("")) {
                    // Signing Up
                    final JSONObject json = new JSONObject();
                    try {
                        json.put("full_name", name);
                        json.put("status", status);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    APIHandler.postRequest(json, AppURLConfig.SAVEDATA_URL, myContext);
                    AppURLConfig.toastMessage(myContext, "Data Was Sent");
                    Intent intent = new Intent(getApplicationContext(), ListViewScreenActivity.class);
                    startActivity(intent);
                }
                else {
                    AppURLConfig.toastMessage(myContext, "Please fill in all text fields.");
                }
            }
        });
        btn_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ListViewScreenActivity.class);
                startActivity(intent);
            }
        });


    }

}

