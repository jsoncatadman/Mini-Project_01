package com.example.testconnection;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.HashMap;

public class ListViewScreenActivity extends AppCompatActivity {

    private Context myContext;
    private ListView listView;
    ArrayList<HashMap<String, String>> data_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview_screen);
        myContext = getApplicationContext();
        data_list = new ArrayList<>();
        listView = findViewById(R.id.list_view);
        APIHandler.getAllPerson(AppURLConfig.GETDATA_URL, myContext, listView, ListViewScreenActivity.this, data_list);
    }
}
